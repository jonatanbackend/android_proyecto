package com.example.myapplication.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.google.android.gms.location.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng

class GPSFragment : Fragment(), OnMapReadyCallback {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationTextView: TextView
    private lateinit var mMap: GoogleMap
    private var isFollowingLocation = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_gps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        locationTextView = view.findViewById(R.id.locationTextView)

        val getLocationButton: Button = view.findViewById(R.id.getLocationButton)
        val toggleFollowButton: Button = view.findViewById(R.id.toggleFollowButton)

        getLocationButton.setOnClickListener { getLastLocation() }

        toggleFollowButton.setOnClickListener {
            isFollowingLocation = !isFollowingLocation
            toggleFollowButton.text = if (isFollowingLocation) "Desactivar seguimiento" else "Activar seguimiento"

            if (isFollowingLocation) {
                startLocationUpdates()
            } else {
                fusedLocationClient.removeLocationUpdates(locationCallback)
            }
        }

        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)

        setupLocationUpdates()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.apply {
            isZoomControlsEnabled = true
            isMapToolbarEnabled = true
            isCompassEnabled = true
            isMyLocationButtonEnabled = true
            isIndoorLevelPickerEnabled = true
        }

        if (hasLocationPermission()) {
            mMap.isMyLocationEnabled = true
            getLastLocation()
        } else {
            requestLocationPermission()
        }
    }

    private fun setupLocationUpdates() {
        locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000).build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    if (isFollowingLocation) {
                        updateLocationOnMap(location)
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        if (!hasLocationPermission()) {
            requestLocationPermission()
            return
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null)
    }

    private fun updateLocationOnMap(location: Location) {
        if (!::mMap.isInitialized) return

        val userLocation = LatLng(location.latitude, location.longitude)

        if (isFollowingLocation) {
            val cameraPosition = CameraPosition.Builder()
                .target(userLocation)
                .zoom(17f)
                .bearing(location.bearing)
                .tilt(60f)
                .build()

            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
        }

        locationTextView.text = "Lat: ${location.latitude}, Lng: ${location.longitude}"
    }

    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                val userLocation = LatLng(it.latitude, it.longitude)
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 17f))
                locationTextView.text = "Lat: ${it.latitude}, Lng: ${it.longitude}"
            } ?: run {
                locationTextView.text = "Ubicación no disponible"
            }
        }.addOnFailureListener {
            locationTextView.text = "Error al obtener ubicación"
        }
    }

    private fun hasLocationPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            requireActivity(),
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            1
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (::locationCallback.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
    }
}
