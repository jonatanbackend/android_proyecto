package com.example.myapplication.ui.home

import android.graphics.*
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.example.myapplication.R

class DrawingFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return DrawingView(requireContext())
    }

    inner class DrawingView(context: android.content.Context) : View(context) {
        private val paint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }
        private val path = Path()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawPath(path, paint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> path.moveTo(event.x, event.y)
                MotionEvent.ACTION_MOVE -> path.lineTo(event.x, event.y)
                MotionEvent.ACTION_UP -> invalidate()
            }
            return true
        }
    }
}
