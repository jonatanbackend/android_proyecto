package com.example.myapplication.ui.login

import com.example.myapplication.ui.home.HomeActivity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.myapplication.R
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.repository.UserRepository
import com.example.myapplication.ui.register.RegisterActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: MaterialButton
    private lateinit var registerButton: MaterialButton

    private lateinit var userRepository: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            // Inicializar UI
            emailEditText = findViewById(R.id.emailEditText)
            passwordEditText = findViewById(R.id.passwordEditText)
            loginButton = findViewById(R.id.loginButton)
            registerButton = findViewById(R.id.registerButton)

            // Inicializar Room y Repository
            val userDao = AppDatabase.getDatabase(this).userDao()
            userRepository = UserRepository(userDao)

            // Evento de Login
            loginButton.setOnClickListener {
                val email = emailEditText.text.toString().trim()
                val password = passwordEditText.text.toString().trim()

                if (validateInputs(email, password)) {
                    loginUser(email, password)
                }
            }

            // Evento de ir a Registro
            registerButton.setOnClickListener {
                startActivity(Intent(this, RegisterActivity::class.java))
            }

        } catch (e: Exception) {
            Log.e("MainActivity", "Error en onCreate: ${e.message}")
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun validateInputs(email: String, password: String): Boolean {
        var isValid = true

        if (email.isEmpty()) {
            emailEditText.error = "El correo no puede estar vacío"
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.error = "Correo inválido (debe contener '@' y un dominio)"
            isValid = false
        } else {
            emailEditText.error = null  // Borra el error si el campo es válido
        }

        if (password.isEmpty()) {
            passwordEditText.error = "La contraseña no puede estar vacía"
            isValid = false
        } else if (password.length < 6) {
            passwordEditText.error = "La contraseña debe tener al menos 6 caracteres"
            isValid = false
        } else {
            passwordEditText.error = null
        }

        return isValid
    }

    private fun loginUser(email: String, password: String) {
        lifecycleScope.launch {
            try {
                val user = userRepository.getUser(email, password)
                if (user != null) {
                    showSuccessDialog()
                } else {
                    Toast.makeText(applicationContext, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error en loginUser: ${e.message}")
                Toast.makeText(applicationContext, "Error al iniciar sesión", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun showSuccessDialog() {
        AlertDialog.Builder(this)
            .setTitle("Inicio de Sesión")
            .setMessage("Inicio de sesión exitoso. ¡Bienvenido!")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                val intent = Intent(this@MainActivity, HomeActivity::class.java)
                startActivity(intent)
                finish()  // Cierra la pantalla de login para que no pueda volver atrás
            }
            .show()
    }
}
